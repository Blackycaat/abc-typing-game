this game is still not finished so you may see alot of bugs 
also the game can crash in some moments
the developer is german so if your english there may be some
wrong  words.

          if you liked it then i dont know subscribe to my channel if 
                                        you want...

https://www.youtube.com/channel/UCrSPqZ7IGNxgyq2ZcoT3EaQ?view_as=subscriber